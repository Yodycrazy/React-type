import { useProducts } from "../../hooks/useProducts";
import React, { useState } from "react";
import Grid from "@mui/material/Grid2";
import MultiActionCard from "../../components/cards/MultiActionCard";
import SearchBar from "../../components/header/SearchBar";
import { Product } from "../../interfaces/Products.interface";

const ProductList = () => {
  const { products, loading, error } = useProducts();
  const [searchQuery, setSearchQuery] = useState("");

  // Filtrar productos según la consulta de búsqueda
  const filteredProducts: Product[] = products.filter((product) =>
    product.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  const handlerButton = () => {
    alert("funcionaaaa");
  };

  return (
    <Grid container spacing={2} columns={16}>
      {/* Buscador */}
      <Grid>
        <SearchBar onSearch={(query) => setSearchQuery(query)} />
      </Grid>

      {/* Lista de Productos Filtrados */}
      {filteredProducts.length === 0 ? (
        <p>No se encontraron productos.</p>
      ) : (
        filteredProducts.map((product, index) => (
          <Grid key={index} size={{ xs: 6, md: 4 }}>
            <MultiActionCard
              item={product}
              valueButton="ver producto"
              onAction={handlerButton}
            />
          </Grid>
        ))
      )}
    </Grid>
  );
};

export default ProductList;